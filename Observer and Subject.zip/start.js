;(function() {

	"use strict";

	define([
		'src/engine/GameLoop',
		'src/engine/GameObject',
		'src/engine/Container',
		'src/engine/Screen',
		'src/engine/Camera',
		'TestPlayer',
		'DeadlyZone'
		], function(GameLoop, GameObject, Container, Screen, Camera, TestPlayer, DeadlyZone) {

		var screen = new Screen(document.getElementById('canvas'));
		screen.setCanvasSize(300, 300);

		var camera = new Camera(screen);

		var gameLoop = new GameLoop();

		GameObject.all = new Container();

		gameLoop.on('update', function(delta) {

			GameObject.all.each(function(gameObject) {
				gameObject.update(delta);
				gameObject.fire('updated', gameObject);
			});
		});

		gameLoop.on('draw', function(delta) {
			screen.context.clearRect(0, 0, screen.canvas.width, screen.canvas.height);

			GameObject.all.each(function(gameObject) {
				if(camera.inViewPort(gameObject.position.x, gameObject.position.y, 100, 100)) {
					gameObject.draw(screen, delta);
					gameObject.fire('drawed', gameObject);	
				}
			});
		});

		GameObject.all.add(new DeadlyZone(), 'deadlyZone');
		GameObject.all.add(new TestPlayer());

		gameLoop.start();
	});

})();