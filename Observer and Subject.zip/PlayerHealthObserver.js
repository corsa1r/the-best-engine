;(function() {

	"use strict";

	define(['src/engine/Observer'], function(Observer) {

		var PlayerHealthObserver = function(target) {
			PlayerHealthObserver.super.constructor.call(this);

			target.on('updated', this.watch.bind(this));
		};

		PlayerHealthObserver.extend(Observer);

		PlayerHealthObserver.prototype.watch = function(target) {
			if(target.health || target.health === 0) {
				this.fire('seen', 'dead', target.health <= 0);
			}
		};

		return PlayerHealthObserver;
	});
})();