;(function() {

	"use strict";

	define([
		'src/engine/Observer',
	 	'src/engine/input/StateMap',
	 	'src/engine/input/KeyboardInput'

	 ], function(Observer, StateMap, KeyboardInput) {

		var KeyboardInputObserver = function(target) {
			KeyboardInputObserver.super.constructor.call(this);

			var stateMap = new StateMap();
			var keyboard = new KeyboardInput();

			keyboard.on('output', stateMap.feed(KeyboardInput.keyMap));
			
			stateMap.on('output', (function(event) {
				
				if(event.which === 'SPACE') {
					this.fire('seen', 'healthPotion', event.state);
				}

				if(event.which === 'A') {
					this.fire('seen', 'move.left', event.state);
				}
				if(event.which === 'D') {
					this.fire('seen', 'move.right', event.state);
				}
				if(event.which === 'W') {
					this.fire('seen', 'move.up', event.state);
				}
				if(event.which === 'S') {
					this.fire('seen', 'move.down', event.state);
				}

			}).bind(this));

			target.on('updated', this.watch.bind(this));
		};

		KeyboardInputObserver.extend(Observer);

		KeyboardInputObserver.prototype.watch = function(target) {

		};

		return KeyboardInputObserver;
	});
})();