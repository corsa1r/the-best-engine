;(function () {
	
	"use strict";

	require.config({
		baseUrl: './'
	});

	require(['start']);

})();