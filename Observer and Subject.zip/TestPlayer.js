;(function () {
	
	"use strict";

	define(['src/engine/GameObject', 'KeyboardInputObserver', 'PlayerHealthObserver', 'PlayerDeadPointObserver'], function(GameObject, KeyboardInputObserver, PlayerHealthObserver, PlayerDeadPointObserver) {

		var TestPlayer = function() {
			TestPlayer.super.constructor.call(this);

			this.subject.subscribe(new KeyboardInputObserver(this));
			this.subject.subscribe(new PlayerHealthObserver(this));
			this.subject.subscribe(new PlayerDeadPointObserver(this));

			this.health = 100;
			this.position = {x: 0, y: 0};
		};

		TestPlayer.extend(GameObject);

		TestPlayer.prototype.update = function(delta) {
			if(this.states.has('healthPotion')) {
				this.health += 4;
			}

			if(this.states.has('dead')) {
				console.log("DEAD");
			} else {
				if(this.states.has('move.up')) {
					this.position.y -= 0.3 * delta;
				}

				if(this.states.has('move.down')) {
					this.position.y += 0.3 * delta;
				}

				if(this.states.has('move.left')) {
					this.position.x -= 0.3 * delta;
				}
				
				if(this.states.has('move.right')) {
					this.position.x += 0.3 * delta;
				}
			}

			if(this.states.has('deadPoint')) {
				this.health--;
			}

			if(this.health <= 0) {
				this.health = 0;
			} else {
				console.log(this.health);
			}
		};

		TestPlayer.prototype.draw = function(screen, delta) {
			screen.context.beginPath();
			screen.context.rect(this.position.x, this.position.y, 100, 100);
			screen.context.fillStyle = 'black';
			screen.context.fill();
		};

		return TestPlayer;
	});

})();