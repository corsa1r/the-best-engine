;(function() {

    define(['src/engine/EventSet', 'src/engine/Subject', 'src/engine/Container'], function(EventSet, Subject, Container) {

        var GameObject = function() {
            GameObject.super.constructor.call(this);

            this.states = new Container();
            this.subject = new Subject(this);

            this.subject.on('state.change', (function(newState, starting) {
                this.states[starting ? 'add' : 'remove'](newState);
            }).bind(this));
        };
        
        GameObject.extend(EventSet);

        /**
        * Abstract methods
        */
        GameObject.prototype.update = function () {};
        GameObject.prototype.draw = function () {};

        return GameObject;
    });
})();