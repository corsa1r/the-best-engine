(function() {
    define([
        'src/engine/helpers/ECMAFixes/FunctionExtend',
        'src/engine/helpers/ECMAFixes/RequestAnimationFrame',
        'src/engine/helpers/ECMAFixes/DateNow',
        'src/engine/helpers/ECMAFixes/FunctionBind',
        'src/engine/helpers/ECMAFixes/FunctionGetName',
        'src/engine/helpers/ECMAFixes/ObjectCombine'
    ]);
})();